<template lang="html">
  <div class="header">
      this is header
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
  .header{
    height: 60px;
    line-height: 60px;
    text-align: center;
    background-color: #286ae8;
  }
</style>
