<template lang="html">
    <div class="page3">
       这是page3
    </div>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
  .page3{
    padding: 20px;
  }
</style>
